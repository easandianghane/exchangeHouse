
package dao;

import connection.ConnectionFactory;
import java.util.List;
import javax.persistence.EntityManager;
import javax.swing.JOptionPane;
import model.Moeda;

/**
 * @author Cinovate lda
 */
public class MoedaDAO {
    public Moeda save(Moeda moeda) {
        EntityManager em = new ConnectionFactory().getConnection();

        try {
            em.getTransaction().begin();
            if (moeda.getId() == null) {
                em.persist(moeda);
            } else {
                em.merge(moeda);
            }
            em.getTransaction().commit();
            JOptionPane.showMessageDialog(null, "Gravado");
        } catch (Exception e) {
            em.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Erro ao Gravar", "Alerta", JOptionPane.WARNING_MESSAGE);

        } finally {
            em.close();
        }
        return moeda;
    }
    
    public Moeda findById(Integer id) {
        EntityManager em = new ConnectionFactory().getConnection();
        Moeda moeda = null;
        try {
            moeda = em.find(Moeda.class, id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Procurar", "Alerta", JOptionPane.WARNING_MESSAGE);
        } finally {
            em.close();
        }
        return moeda;
    }
    
    public Moeda findByName(String name) {
        EntityManager em = new ConnectionFactory().getConnection();
        Moeda moeda = new Moeda();
        try {
            moeda = em.find(Moeda.class, name);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Procurar", "Alerta", JOptionPane.WARNING_MESSAGE);
        } finally {
            em.close();
        }
        return moeda;
    }
    
    public Moeda delete(Integer id) {
        EntityManager em = new ConnectionFactory().getConnection();
        Moeda moeda = em.find(Moeda.class, id);
        try {
            em.getTransaction().begin();
            em.remove(moeda);
            em.getTransaction().commit();
            JOptionPane.showMessageDialog(null, "Apagado");
        } catch (Exception e) {
            em.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Erro ao Apagar", "Alerta", JOptionPane.WARNING_MESSAGE);
        } finally {
            em.close();
        }
        return moeda;
    }

    public List<Moeda> listAll() {
        EntityManager em = new ConnectionFactory().getConnection();
        List<Moeda> moedas = null;

        try {
            moedas = em.createQuery("from Moeda").getResultList();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Listar", "Alerta", JOptionPane.WARNING_MESSAGE);
        } finally {
            em.close();
        }
        return moedas;
    }
}