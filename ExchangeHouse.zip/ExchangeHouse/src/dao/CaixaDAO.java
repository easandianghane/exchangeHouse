/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import connection.ConnectionFactory;
import java.util.List;
import javax.persistence.EntityManager;
import javax.swing.JOptionPane;
import model.Caixa;

/**
 *
 * @author Cinovate lda
 */
public class CaixaDAO {
    public Caixa save(Caixa caixa) {
        EntityManager em = new ConnectionFactory().getConnection();

        try {
            em.getTransaction().begin();
            if (caixa.getId() == null) {
                em.persist(caixa);
            } else {
                em.merge(caixa);
            }
            em.getTransaction().commit();
            //JOptionPane.showMessageDialog(null, "Gravado");
        } catch (Exception e) {
            em.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Erro ao Gravar", "Alerta", JOptionPane.WARNING_MESSAGE);

        } finally {
            em.close();
        }
        return caixa;
    }
    
    public Caixa findById(Integer id) {
        EntityManager em = new ConnectionFactory().getConnection();
        Caixa caixa = null;
        try {
            caixa = em.find(Caixa.class, id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Procurar", "Alerta", JOptionPane.WARNING_MESSAGE);
        } finally {
            em.close();
        }
        return caixa;
    }
    
    public Caixa delete(Integer id) {
        EntityManager em = new ConnectionFactory().getConnection();
        Caixa caixa = em.find(Caixa.class, id);
        try {
            em.getTransaction().begin();
            em.remove(caixa);
            em.getTransaction().commit();
            JOptionPane.showMessageDialog(null, "Apagado");
        } catch (Exception e) {
            em.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Erro ao Apagar", "Alerta", JOptionPane.WARNING_MESSAGE);

        } finally {
            em.close();
        }
        return caixa;
    }

    public List<Caixa> listAll() {
        EntityManager em = new ConnectionFactory().getConnection();
        List<Caixa> caixas = null;

        try {
            caixas = em.createQuery("from Caixa").getResultList();
        } catch (Exception e) {
            //em.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Erro ao Listar", "Alerta", JOptionPane.WARNING_MESSAGE);

        } finally {
            em.close();
        }
        return caixas;
    }
}
