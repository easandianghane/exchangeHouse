/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import connection.ConnectionFactory;
import java.util.List;
import javax.persistence.EntityManager;
import javax.swing.JOptionPane;
import model.Vendedor;

/**
 *
 * @author Cinovate lda
 */
public class VendedorDAO {
    public Vendedor save(Vendedor vendedor) {
        EntityManager em = new ConnectionFactory().getConnection();

        try {
            em.getTransaction().begin();
            if (vendedor.getId() == null) {
                em.persist(vendedor);
            } else {
                em.merge(vendedor);
            }
            em.getTransaction().commit();
            JOptionPane.showMessageDialog(null, "Gravado");
        } catch (Exception e) {
            em.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Erro ao Gravar", "Alerta", JOptionPane.WARNING_MESSAGE);

        } finally {
            em.close();
        }
        return vendedor;
    }
    
    public Vendedor findById(Integer id) {
        EntityManager em = new ConnectionFactory().getConnection();
        Vendedor vendedor = null;
        try {
            vendedor = em.find(Vendedor.class, id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Procurar", "Alerta", JOptionPane.WARNING_MESSAGE);
        } finally {
            em.close();
        }
        return vendedor;
    }
    
    public Vendedor delete(Integer id) {
        EntityManager em = new ConnectionFactory().getConnection();
        Vendedor vendedor = em.find(Vendedor.class, id);
        try {
            em.getTransaction().begin();
            em.remove(vendedor);
            em.getTransaction().commit();
            JOptionPane.showMessageDialog(null, "Apagado");
        } catch (Exception e) {
            em.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Erro ao Apagar", "Alerta", JOptionPane.WARNING_MESSAGE);

        } finally {
            em.close();
        }
        return vendedor;
    }

    public List<Vendedor> listAll() {
        EntityManager em = new ConnectionFactory().getConnection();
        List<Vendedor> vendedors = null;

        try {
            vendedors = em.createQuery("from Vendedor").getResultList();
        } catch (Exception e) {
            //em.getTransaction().rollback();
            JOptionPane.showMessageDialog(null, "Erro ao Listar", "Alerta", JOptionPane.WARNING_MESSAGE);

        } finally {
            em.close();
        }
        return vendedors;
    }
}
