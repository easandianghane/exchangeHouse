
package casadecambio;

import view.Login;

/**
 * @author Cinovate lda
 */
public class CasaDeCambio {
    public static void main(String[] args) {
        Login tela = new Login();
        tela.setVisible(true);
    }    
}
